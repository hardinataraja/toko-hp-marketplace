// lib/models/product_model.dart

class Product {
  final String id;
  final String name;
  final String brand;
  final double price;
  final double? originalPrice;
  final String imageUrl;
  final String category;
  final double rating;
  final int sold;
  final int stock;
  final String description;
  final List<String> specs;
  final bool isFeatured;
  final bool isFlashSale;

  Product({
    required this.id,
    required this.name,
    required this.brand,
    required this.price,
    this.originalPrice,
    required this.imageUrl,
    required this.category,
    required this.rating,
    required this.sold,
    required this.stock,
    required this.description,
    required this.specs,
    this.isFeatured = false,
    this.isFlashSale = false,
  });

  double? get discountPercent {
    if (originalPrice == null) return null;
    return ((originalPrice! - price) / originalPrice! * 100);
  }
}

class ServiceItem {
  final String id;
  final String title;
  final String description;
  final double price;
  final String imageUrl;
  final String category;
  final int estimasiHari;

  ServiceItem({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.imageUrl,
    required this.category,
    required this.estimasiHari,
  });
}

class CourseItem {
  final String id;
  final String title;
  final String instructor;
  final double price;
  final String imageUrl;
  final double rating;
  final int participants;
  final int durasiJam;
  final String level;

  CourseItem({
    required this.id,
    required this.title,
    required this.instructor,
    required this.price,
    required this.imageUrl,
    required this.rating,
    required this.participants,
    required this.durasiJam,
    required this.level,
  });
}

class CartItem {
  final Product product;
  int quantity;

  CartItem({required this.product, this.quantity = 1});
}
