// lib/utils/format_utils.dart

import 'package:intl/intl.dart';

class FormatUtils {
  static String currency(double amount) {
    final formatter = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    );
    return formatter.format(amount);
  }

  static String sold(int count) {
    if (count >= 1000) {
      return '${(count / 1000).toStringAsFixed(1)}rb';
    }
    return count.toString();
  }
}
