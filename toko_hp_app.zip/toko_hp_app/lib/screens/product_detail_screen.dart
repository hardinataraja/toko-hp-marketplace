// lib/screens/product_detail_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/cart_provider.dart';
import '../models/product_model.dart';
import '../utils/app_theme.dart';
import '../utils/format_utils.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  int _qty = 1;
  bool _showFullDesc = false;

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final product = widget.product;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // App Bar with image
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            backgroundColor: Colors.white,
            foregroundColor: AppColors.textPrimary,
            actions: [
              IconButton(
                onPressed: () => cart.toggleWishlist(product),
                icon: Icon(
                  cart.isInWishlist(product.id) ? Icons.favorite : Icons.favorite_border,
                  color: cart.isInWishlist(product.id) ? AppColors.error : AppColors.textSecondary,
                ),
              ),
              IconButton(onPressed: () {}, icon: const Icon(Icons.share_outlined)),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    product.imageUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(color: AppColors.divider,
                        child: const Icon(Icons.image_not_supported, size: 60, color: AppColors.textHint)),
                  ),
                  if (product.discountPercent != null)
                    Positioned(
                      bottom: 16, left: 16,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: AppColors.error, borderRadius: BorderRadius.circular(6)),
                        child: Text('DISKON ${product.discountPercent!.toInt()}%',
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                      ),
                    ),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // === PRICE & NAME ===
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  FormatUtils.currency(product.price),
                                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppColors.primary),
                                ),
                                if (product.originalPrice != null)
                                  Row(
                                    children: [
                                      Text(
                                        FormatUtils.currency(product.originalPrice!),
                                        style: const TextStyle(fontSize: 13, color: AppColors.textHint, decoration: TextDecoration.lineThrough),
                                      ),
                                      const SizedBox(width: 8),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: AppColors.error.withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(4),
                                          border: Border.all(color: AppColors.error),
                                        ),
                                        child: Text(
                                          'Hemat ${FormatUtils.currency(product.originalPrice! - product.price)}',
                                          style: const TextStyle(fontSize: 10, color: AppColors.error, fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ],
                                  ),
                              ],
                            ),
                          ),
                          // Qty Counter
                          Row(
                            children: [
                              GestureDetector(
                                onTap: () { if (_qty > 1) setState(() => _qty--); },
                                child: Container(
                                  width: 32, height: 32,
                                  decoration: BoxDecoration(
                                    border: Border.all(color: AppColors.divider),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Icon(Icons.remove, size: 16),
                                ),
                              ),
                              Container(
                                width: 40,
                                alignment: Alignment.center,
                                child: Text('$_qty', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                              ),
                              GestureDetector(
                                onTap: () { if (_qty < product.stock) setState(() => _qty++); },
                                child: Container(
                                  width: 32, height: 32,
                                  decoration: BoxDecoration(
                                    color: AppColors.primary,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Icon(Icons.add, size: 16, color: Colors.white),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(product.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(Icons.star, color: AppColors.secondary, size: 16),
                          Text(' ${product.rating}  ', style: const TextStyle(fontWeight: FontWeight.w600)),
                          Text('| ${FormatUtils.sold(product.sold)} terjual', style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: product.stock > 0 ? AppColors.success.withOpacity(0.1) : AppColors.error.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              product.stock > 0 ? 'Stok: ${product.stock}' : 'Habis',
                              style: TextStyle(
                                color: product.stock > 0 ? AppColors.success : AppColors.error,
                                fontSize: 12, fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                // === SHIPPING INFO ===
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _infoRow(Icons.location_on_outlined, 'Dikirim dari', 'Jakarta Pusat', AppColors.textSecondary),
                      const SizedBox(height: 10),
                      _infoRow(Icons.local_shipping_outlined, 'Pengiriman', 'Gratis Ongkir • JNE, SiCepat, J&T', AppColors.success),
                      const SizedBox(height: 10),
                      _infoRow(Icons.verified_user_outlined, 'Garansi', 'Garansi Toko 7 hari', AppColors.primary),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                // === SPECS ===
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Spesifikasi', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      ...product.specs.map((spec) {
                        final parts = spec.split(': ');
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 110,
                                child: Text(parts.isNotEmpty ? parts[0] : spec,
                                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                              ),
                              Expanded(
                                child: Text(parts.length > 1 ? parts[1] : '',
                                    style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
                              ),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                // === DESCRIPTION ===
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Deskripsi Produk', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      Text(
                        product.description,
                        maxLines: _showFullDesc ? null : 3,
                        overflow: _showFullDesc ? null : TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6),
                      ),
                      const SizedBox(height: 8),
                      GestureDetector(
                        onTap: () => setState(() => _showFullDesc = !_showFullDesc),
                        child: Text(
                          _showFullDesc ? 'Sembunyikan ▲' : 'Selengkapnya ▼',
                          style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                ),

                // === SELLER INFO ===
                Container(
                  margin: const EdgeInsets.only(top: 8),
                  color: Colors.white,
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 50, height: 50,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Center(child: Icon(Icons.store, color: Colors.white, size: 24)),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('TokoHP Official', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                            Text('Jakarta Pusat • Online 1 jam lalu', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                            Row(children: [
                              Icon(Icons.star, color: AppColors.secondary, size: 14),
                              Text(' 4.9 (2.4rb ulasan)', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                            ]),
                          ],
                        ),
                      ),
                      OutlinedButton(
                        onPressed: () {},
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: AppColors.primary),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        ),
                        child: const Text('Kunjungi', style: TextStyle(color: AppColors.primary, fontSize: 12)),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 100),
              ],
            ),
          ),
        ],
      ),

      // === BOTTOM ACTION BAR ===
      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, -2))],
        ),
        child: Row(
          children: [
            // Chat button
            Container(
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.primary),
                borderRadius: BorderRadius.circular(8),
              ),
              child: IconButton(
                onPressed: () {},
                icon: const Icon(Icons.chat_outlined, color: AppColors.primary),
              ),
            ),
            const SizedBox(width: 8),
            // Add to Cart
            Expanded(
              child: OutlinedButton(
                onPressed: () {
                  for (int i = 0; i < _qty; i++) {
                    cart.addToCart(product);
                  }
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${product.name} ditambahkan ke keranjang'),
                      backgroundColor: AppColors.success,
                      behavior: SnackBarBehavior.floating,
                      duration: const Duration(seconds: 2),
                    ),
                  );
                },
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.primary),
                  foregroundColor: AppColors.primary,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: const Text('+ Keranjang', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(width: 8),
            // Buy Now
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  cart.addToCart(product);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const _CheckoutPlaceholder()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: const Text('Beli Sekarang', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value, Color iconColor) {
    return Row(
      children: [
        Icon(icon, size: 18, color: iconColor),
        const SizedBox(width: 8),
        Text('$label  ', style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
        Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13))),
      ],
    );
  }
}

class _CheckoutPlaceholder extends StatelessWidget {
  const _CheckoutPlaceholder();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout'), backgroundColor: AppColors.primary, foregroundColor: Colors.white),
      body: const Center(child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.check_circle, color: AppColors.success, size: 80),
          SizedBox(height: 16),
          Text('Fitur Checkout', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('Segera hadir!', style: TextStyle(color: AppColors.textSecondary)),
        ],
      )),
    );
  }
}
