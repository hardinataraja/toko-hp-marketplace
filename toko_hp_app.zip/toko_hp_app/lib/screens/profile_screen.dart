// lib/screens/profile_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/cart_provider.dart';
import '../utils/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            backgroundColor: AppColors.primary,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppColors.primary, AppColors.primaryLight],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const CircleAvatar(
                        radius: 40,
                        backgroundColor: Colors.white,
                        child: Icon(Icons.person,
                            size: 40, color: AppColors.primary),
                      ),
                      const SizedBox(height: 10),
                      const Text('Pengguna TokoHP',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold)),
                      const Text('+62 812-3456-7890',
                          style:
                              TextStyle(color: Colors.white70, fontSize: 13)),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                          border:
                              Border.all(color: Colors.white.withOpacity(0.4)),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.diamond,
                                color: AppColors.secondary, size: 14),
                            SizedBox(width: 4),
                            Text('Member Silver',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Column(
              children: [
                // Stats Row
                Container(
                  margin: const EdgeInsets.all(12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(0.05), blurRadius: 8)
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _statItem(
                          '3', 'Pesanan Aktif', Icons.inventory_2_outlined),
                      _divider(),
                      _statItem('${cart.wishlist.length}', 'Wishlist',
                          Icons.favorite_outline),
                      _divider(),
                      _statItem('12', 'Ulasan', Icons.star_outline),
                      _divider(),
                      _statItem('Rp 0', 'Poin', Icons.monetization_on_outlined),
                    ],
                  ),
                ),

                // Order Status
                _buildSection(
                    'Pesanan Saya',
                    [
                      _orderStatusItem(Icons.payment_outlined,
                          'Menunggu Pembayaran', '2', AppColors.warning),
                      _orderStatusItem(Icons.inventory_outlined, 'Dikemas', '1',
                          AppColors.primary),
                      _orderStatusItem(Icons.local_shipping_outlined, 'Dikirim',
                          '0', Colors.blue),
                      _orderStatusItem(Icons.check_circle_outline, 'Selesai',
                          '5', AppColors.success),
                    ],
                    isRow: true),

                // Services
                _buildSection('Layanan Saya', [
                  _menuItem(Icons.build_outlined, 'Riwayat Servis', ''),
                  _menuItem(Icons.school_outlined, 'Kursus Saya', ''),
                  _menuItem(Icons.print_outlined, 'Riwayat Print', ''),
                ]),

                // Account
                _buildSection('Akun', [
                  _menuItem(Icons.person_outline, 'Edit Profil', ''),
                  _menuItem(
                      Icons.location_on_outlined, 'Alamat Pengiriman', ''),
                  _menuItem(
                      Icons.credit_card_outlined, 'Metode Pembayaran', ''),
                  _menuItem(Icons.notifications_outlined, 'Notifikasi', ''),
                  _menuItem(Icons.help_outline, 'Bantuan & FAQ', ''),
                  _menuItem(Icons.logout, 'Keluar', '', isDestructive: true),
                ]),

                const SizedBox(height: 80),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statItem(String value, String label, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: AppColors.primary, size: 22),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        Text(label,
            style:
                const TextStyle(color: AppColors.textSecondary, fontSize: 10),
            textAlign: TextAlign.center),
      ],
    );
  }

  Widget _divider() =>
      Container(width: 1, height: 40, color: AppColors.divider);

  Widget _buildSection(String title, List<Widget> children,
      {bool isRow = false}) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Text(title,
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          ),
          const Divider(height: 1),
          if (isRow)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: children),
            )
          else
            ...children,
        ],
      ),
    );
  }

  Widget _orderStatusItem(
      IconData icon, String label, String count, Color color) {
    return Column(
      children: [
        Stack(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: color, size: 24),
            ),
            if (count != '0')
              Positioned(
                right: 0,
                top: 0,
                child: Container(
                  width: 18,
                  height: 18,
                  decoration: const BoxDecoration(
                      color: AppColors.badge, shape: BoxShape.circle),
                  child: Center(
                      child: Text(count,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold))),
                ),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Text(label,
            style:
                const TextStyle(fontSize: 11, color: AppColors.textSecondary),
            textAlign: TextAlign.center),
      ],
    );
  }

  Widget _menuItem(IconData icon, String label, String trailing,
      {bool isDestructive = false}) {
    return ListTile(
      leading: Icon(icon,
          color: isDestructive ? AppColors.error : AppColors.textSecondary),
      title: Text(label,
          style: TextStyle(
              fontSize: 14,
              color: isDestructive ? AppColors.error : AppColors.textPrimary)),
      trailing: trailing.isNotEmpty
          ? Text(trailing,
              style:
                  const TextStyle(color: AppColors.textSecondary, fontSize: 12))
          : const Icon(Icons.chevron_right,
              color: AppColors.textHint, size: 20),
      onTap: () {},
    );
  }
}
