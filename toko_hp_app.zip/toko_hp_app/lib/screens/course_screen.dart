// lib/screens/course_screen.dart

import 'package:flutter/material.dart';
import '../data/dummy_data.dart';
import '../utils/app_theme.dart';
import '../utils/format_utils.dart';

class CourseScreen extends StatelessWidget {
  const CourseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kursus Teknisi'),
        backgroundColor: const Color(0xFF1A237E),
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('🎓 Jadilah Teknisi Profesional',
                    style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('Pelajari dari para ahli berpengalaman\nSertifikat resmi setelah lulus',
                    style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.5)),
                const SizedBox(height: 16),
                Row(
                  children: [
                    _statBadge(Icons.people, '5.000+ alumni'),
                    const SizedBox(width: 12),
                    _statBadge(Icons.star, 'Rating 4.8/5'),
                    const SizedBox(width: 12),
                    _statBadge(Icons.workspace_premium, 'Bersertifikat'),
                  ],
                ),
              ],
            ),
          ),

          // Course List
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: DummyData.courses.length,
              itemBuilder: (context, index) {
                final course = DummyData.courses[index];
                return GestureDetector(
                  onTap: () => _showCourseDetail(context, course),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 2))],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Stack(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.only(topLeft: Radius.circular(14), topRight: Radius.circular(14)),
                              child: Image.network(
                                course.imageUrl,
                                height: 160, width: double.infinity, fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(height: 160, color: AppColors.divider),
                              ),
                            ),
                            Positioned(
                              top: 12, left: 12,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _getLevelColor(course.level),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(course.level,
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(course.title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, height: 1.3)),
                              const SizedBox(height: 6),
                              Text('Oleh: ${course.instructor}',
                                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  const Icon(Icons.star, color: AppColors.secondary, size: 16),
                                  Text(' ${course.rating}  ', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                                  const Icon(Icons.people_outline, size: 16, color: AppColors.textSecondary),
                                  Text(' ${FormatUtils.sold(course.participants)} peserta',
                                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                                  const Spacer(),
                                  const Icon(Icons.schedule, size: 14, color: AppColors.textSecondary),
                                  Text(' ${course.durasiJam} jam',
                                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                                ],
                              ),
                              const Divider(height: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(FormatUtils.currency(course.price),
                                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.primary)),
                                  ElevatedButton(
                                    onPressed: () => _showCourseDetail(context, course),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF1A237E),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                    ),
                                    child: const Text('Daftar', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _statBadge(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white, size: 13),
          const SizedBox(width: 4),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 11)),
        ],
      ),
    );
  }

  Color _getLevelColor(String level) {
    switch (level) {
      case 'Pemula': return Colors.green;
      case 'Menengah': return Colors.orange;
      case 'Advanced': return Colors.red;
      default: return Colors.blue;
    }
  }

  void _showCourseDetail(BuildContext context, course) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        minChildSize: 0.4,
        expand: false,
        builder: (context, scrollController) => SingleChildScrollView(
          controller: scrollController,
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.divider, borderRadius: BorderRadius.circular(2)))),
                const SizedBox(height: 16),
                Text(course.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Oleh: ${course.instructor}', style: const TextStyle(color: AppColors.textSecondary)),
                const SizedBox(height: 16),
                const Text('Yang akan kamu pelajari:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                const SizedBox(height: 10),
                ...[
                  'Dasar-dasar elektronik dan komponen HP',
                  'Identifikasi kerusakan hardware',
                  'Teknik penggantian LCD, baterai, konektor',
                  'Flashing dan pemulihan software',
                  'Manajemen bisnis servis HP',
                ].map((item) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      const Icon(Icons.check_circle, color: AppColors.success, size: 18),
                      const SizedBox(width: 8),
                      Expanded(child: Text(item, style: const TextStyle(fontSize: 13))),
                    ],
                  ),
                )),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Pendaftaran berhasil! Tim kami akan menghubungi Anda'), backgroundColor: AppColors.success),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1A237E),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text('Daftar Sekarang - ${FormatUtils.currency(course.price)}',
                        style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
