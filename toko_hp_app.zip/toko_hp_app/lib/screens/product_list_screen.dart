// lib/screens/product_list_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/cart_provider.dart';
import '../data/dummy_data.dart';
import '../utils/app_theme.dart';
import '../widgets/product_card.dart';
import 'product_detail_screen.dart';

class ProductListScreen extends StatefulWidget {
  final String category;
  final String title;
  const ProductListScreen(
      {super.key, required this.category, required this.title});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  String _sortBy = 'Terbaru';
  final List<String> _sortOptions = [
    'Terbaru',
    'Termurah',
    'Termahal',
    'Terlaris',
    'Rating'
  ];

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    var products =
        DummyData.products.where((p) => p.category == widget.category).toList();

    // Sort
    switch (_sortBy) {
      case 'Termurah':
        products.sort((a, b) => a.price.compareTo(b.price));
        break;
      case 'Termahal':
        products.sort((a, b) => b.price.compareTo(a.price));
        break;
      case 'Terlaris':
        products.sort((a, b) => b.sold.compareTo(a.sold));
        break;
      case 'Rating':
        products.sort((a, b) => b.rating.compareTo(a.rating));
        break;
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.filter_list)),
        ],
      ),
      body: Column(
        children: [
          // Sort Bar
          Container(
            color: Colors.white,
            height: 44,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: _sortOptions.length,
              itemBuilder: (context, index) {
                final option = _sortOptions[index];
                final isSelected = _sortBy == option;
                return GestureDetector(
                  onTap: () => setState(() => _sortBy = option),
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    decoration: BoxDecoration(
                      color: isSelected ? AppColors.primary : Colors.white,
                      border: Border.all(
                          color: isSelected
                              ? AppColors.primary
                              : AppColors.divider),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(option,
                        style: TextStyle(
                          color: isSelected
                              ? Colors.white
                              : AppColors.textSecondary,
                          fontSize: 12,
                          fontWeight:
                              isSelected ? FontWeight.bold : FontWeight.normal,
                        )),
                  ),
                );
              },
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 0.62,
              ),
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return ProductCard(
                  product: product,
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) =>
                              ProductDetailScreen(product: product))),
                  isWishlisted: cart.isInWishlist(product.id),
                  onWishlistToggle: () => cart.toggleWishlist(product),
                  onAddToCart: () => cart.addToCart(product),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
