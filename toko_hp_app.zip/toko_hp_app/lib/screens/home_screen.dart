// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/cart_provider.dart';
import '../data/dummy_data.dart';
import '../models/product_model.dart';
import '../utils/app_theme.dart';
import '../utils/format_utils.dart';
import '../widgets/product_card.dart';
import 'product_detail_screen.dart';
import 'cart_screen.dart';
import 'service_screen.dart';
import 'course_screen.dart';
import 'product_list_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentBanner = 0;
  final PageController _bannerController = PageController();
  final TextEditingController _searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // === APP BAR ===
          SliverAppBar(
            pinned: true,
            floating: true,
            backgroundColor: AppColors.primary,
            expandedHeight: 110,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                color: AppColors.primary,
                padding: const EdgeInsets.fromLTRB(16, 48, 16, 0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.storefront, color: Colors.white, size: 24),
                        const SizedBox(width: 8),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('TokoHP', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
                            Text('Jl. Teknologi No.1, Jakarta', style: TextStyle(color: Colors.white70, fontSize: 11)),
                          ],
                        ),
                        const Spacer(),
                        Stack(
                          children: [
                            IconButton(
                              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
                              icon: const Icon(Icons.shopping_cart_outlined, color: Colors.white),
                            ),
                            if (cart.itemCount > 0)
                              Positioned(
                                right: 6, top: 6,
                                child: Container(
                                  padding: const EdgeInsets.all(3),
                                  decoration: const BoxDecoration(color: AppColors.secondary, shape: BoxShape.circle),
                                  child: Text('${cart.itemCount}', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold)),
                                ),
                              ),
                          ],
                        ),
                        IconButton(
                          onPressed: () {},
                          icon: const Icon(Icons.chat_bubble_outline, color: Colors.white),
                        ),
                        IconButton(
                          onPressed: () {},
                          icon: const Icon(Icons.notifications_outlined, color: Colors.white),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(50),
              child: Container(
                color: AppColors.primary,
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Cari HP, Laptop, Aksesoris...',
                    hintStyle: const TextStyle(fontSize: 13, color: AppColors.textHint),
                    prefixIcon: const Icon(Icons.search, color: AppColors.textHint, size: 20),
                    suffixIcon: const Icon(Icons.camera_alt_outlined, color: AppColors.textHint, size: 20),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.symmetric(vertical: 0),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                  ),
                ),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // === BANNER CAROUSEL ===
                _buildBannerCarousel(),

                // === CATEGORY MENU ===
                _buildCategoryMenu(context),

                // === FLASH SALE ===
                _buildFlashSaleSection(context, cart),

                // === KATEGORI HP ===
                _buildProductSection(
                  context, cart,
                  title: '📱 Smartphone Terbaru',
                  products: DummyData.products.where((p) => p.category == 'smartphone').toList(),
                  onSeeAll: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const ProductListScreen(category: 'smartphone', title: 'Smartphone'))),
                ),

                // === KATEGORI LAPTOP ===
                _buildProductSection(
                  context, cart,
                  title: '💻 Laptop Pilihan',
                  products: DummyData.products.where((p) => p.category == 'laptop').toList(),
                  onSeeAll: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const ProductListScreen(category: 'laptop', title: 'Laptop'))),
                ),

                // === SERVIS ===
                _buildServiceSection(context),

                // === KURSUS ===
                _buildCourseSection(context),

                // === AKSESORIS ===
                _buildProductSection(
                  context, cart,
                  title: '🎧 Aksesoris & Custom Case',
                  products: DummyData.products.where((p) => p.category == 'aksesoris').toList(),
                  onSeeAll: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const ProductListScreen(category: 'aksesoris', title: 'Aksesoris'))),
                ),

                const SizedBox(height: 80),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBannerCarousel() {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          SizedBox(
            height: 160,
            child: PageView.builder(
              controller: _bannerController,
              onPageChanged: (i) => setState(() => _currentBanner = i),
              itemCount: DummyData.banners.length,
              itemBuilder: (context, index) {
                final banner = DummyData.banners[index];
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    color: Color(banner['bgColor'] as int),
                    borderRadius: BorderRadius.circular(0),
                  ),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        banner['image'] as String,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(color: Color(banner['bgColor'] as int)),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                            colors: [Color(banner['bgColor'] as int).withOpacity(0.85), Colors.transparent],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 20, top: 0, bottom: 0,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(banner['title'] as String,
                                style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 6),
                            Text(banner['subtitle'] as String,
                                style: const TextStyle(color: Colors.white, fontSize: 13)),
                            const SizedBox(height: 12),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Text('Beli Sekarang',
                                  style: TextStyle(color: AppColors.primary, fontSize: 12, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(DummyData.banners.length, (i) => Container(
              width: i == _currentBanner ? 16 : 6,
              height: 6,
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                color: i == _currentBanner ? AppColors.primary : AppColors.divider,
                borderRadius: BorderRadius.circular(3),
              ),
            )),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildCategoryMenu(BuildContext context) {
    final categories = [
      {'icon': Icons.smartphone, 'label': 'Smartphone', 'color': 0xFFE91E63},
      {'icon': Icons.laptop_mac, 'label': 'Laptop', 'color': 0xFF2196F3},
      {'icon': Icons.headphones, 'label': 'Aksesoris', 'color': 0xFF9C27B0},
      {'icon': Icons.build_circle, 'label': 'Servis', 'color': 0xFF4CAF50},
      {'icon': Icons.school, 'label': 'Kursus', 'color': 0xFFFF9800},
      {'icon': Icons.print, 'label': 'Print Case', 'color': 0xFF00BCD4},
      {'icon': Icons.local_offer, 'label': 'Flash Sale', 'color': 0xFFEE4D2D},
      {'icon': Icons.more_horiz, 'label': 'Lainnya', 'color': 0xFF607D8B},
    ];

    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: GridView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          mainAxisSpacing: 16,
          crossAxisSpacing: 4,
          childAspectRatio: 0.85,
        ),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final cat = categories[index];
          return GestureDetector(
            onTap: () {
              if (cat['label'] == 'Servis') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ServiceScreen()));
              } else if (cat['label'] == 'Kursus') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const CourseScreen()));
              } else if (cat['label'] == 'Smartphone') {
                Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const ProductListScreen(category: 'smartphone', title: 'Smartphone')));
              } else if (cat['label'] == 'Laptop') {
                Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const ProductListScreen(category: 'laptop', title: 'Laptop')));
              } else if (cat['label'] == 'Aksesoris' || cat['label'] == 'Print Case') {
                Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const ProductListScreen(category: 'aksesoris', title: 'Aksesoris')));
              }
            },
            child: Column(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: Color(cat['color'] as int).withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(cat['icon'] as IconData, color: Color(cat['color'] as int), size: 26),
                ),
                const SizedBox(height: 6),
                Text(
                  cat['label'] as String,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: AppColors.textPrimary),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildFlashSaleSection(BuildContext context, CartProvider cart) {
    final flashSaleProducts = DummyData.products.where((p) => p.isFlashSale).toList();

    return Container(
      margin: const EdgeInsets.only(top: 8),
      color: Colors.white,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.bolt, color: Colors.white, size: 16),
                      SizedBox(width: 4),
                      Text('FLASH SALE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.primary),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text('Berakhir dalam 05:32:11',
                      style: TextStyle(fontSize: 11, color: AppColors.primary, fontWeight: FontWeight.w500)),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () {},
                  child: const Text('Lihat Semua >', style: TextStyle(color: AppColors.primary, fontSize: 12)),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 240,
            child: ListView.builder(
              padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
              scrollDirection: Axis.horizontal,
              itemCount: flashSaleProducts.length,
              itemBuilder: (context, index) {
                final product = flashSaleProducts[index];
                return Container(
                  width: 150,
                  margin: const EdgeInsets.only(right: 10),
                  child: ProductCard(
                    product: product,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product))),
                    isWishlisted: cart.isInWishlist(product.id),
                    onWishlistToggle: () => cart.toggleWishlist(product),
                    onAddToCart: () => cart.addToCart(product),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductSection(BuildContext context, CartProvider cart,
      {required String title, required List<Product> products, required VoidCallback onSeeAll}) {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      color: Colors.white,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 8, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                TextButton(onPressed: onSeeAll, child: const Text('Lihat Semua >', style: TextStyle(color: AppColors.primary, fontSize: 12))),
              ],
            ),
          ),
          SizedBox(
            height: 260,
            child: ListView.builder(
              padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
              scrollDirection: Axis.horizontal,
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return Container(
                  width: 160,
                  margin: const EdgeInsets.only(right: 10),
                  child: ProductCard(
                    product: product,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product))),
                    isWishlisted: cart.isInWishlist(product.id),
                    onWishlistToggle: () => cart.toggleWishlist(product),
                    onAddToCart: () => cart.addToCart(product),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildServiceSection(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      color: Colors.white,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 8, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('🔧 Layanan Servis', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                TextButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ServiceScreen())),
                  child: const Text('Lihat Semua >', style: TextStyle(color: AppColors.primary, fontSize: 12)),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 200,
            child: ListView.builder(
              padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
              scrollDirection: Axis.horizontal,
              itemCount: DummyData.services.take(4).length,
              itemBuilder: (context, index) {
                final service = DummyData.services[index];
                return Container(
                  margin: const EdgeInsets.only(right: 10),
                  child: ServiceCard(
                    service: service,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ServiceScreen())),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCourseSection(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 8, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('🎓 Kursus Teknisi', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                    Text('Kuasai skill servis HP & Laptop', style: TextStyle(fontSize: 12, color: Colors.white70)),
                  ],
                ),
                TextButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CourseScreen())),
                  child: const Text('Lihat Semua >', style: TextStyle(color: Colors.white, fontSize: 12)),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 180,
            child: ListView.builder(
              padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
              scrollDirection: Axis.horizontal,
              itemCount: DummyData.courses.take(3).length,
              itemBuilder: (context, index) {
                final course = DummyData.courses[index];
                return GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CourseScreen())),
                  child: Container(
                    width: 220,
                    margin: const EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white.withOpacity(0.2)),
                    ),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(12), bottomLeft: Radius.circular(12)),
                          child: Image.network(course.imageUrl, width: 90, height: double.infinity,
                              fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: 90, color: Colors.white24)),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _getLevelColor(course.level),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(course.level,
                                      style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                                ),
                                const SizedBox(height: 6),
                                Text(course.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                                const SizedBox(height: 4),
                                Row(children: [
                                  const Icon(Icons.star, color: AppColors.secondary, size: 12),
                                  Text(' ${course.rating}', style: const TextStyle(color: Colors.white70, fontSize: 10)),
                                  Text(' • ${course.durasiJam}j', style: const TextStyle(color: Colors.white70, fontSize: 10)),
                                ]),
                                const SizedBox(height: 6),
                                Text(FormatUtils.currency(course.price),
                                    style: const TextStyle(color: AppColors.secondary, fontSize: 13, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 4),
        ],
      ),
    );
  }

  Color _getLevelColor(String level) {
    switch (level) {
      case 'Pemula': return Colors.green;
      case 'Menengah': return Colors.orange;
      case 'Advanced': return Colors.red;
      default: return Colors.blue;
    }
  }
}
